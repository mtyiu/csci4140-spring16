CREATE TABLE `images` (
  `filename` varchar(255) NOT NULL,
  `imagetype` varchar(5) NOT NULL
);
