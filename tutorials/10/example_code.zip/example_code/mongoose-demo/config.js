module.exports = process.env.MONGOLAB_URI || 'mongodb://heroku_bbxgs9qk:egqml99fqbcc82vopjabco1apr@ds025419.mlab.com:25419/heroku_bbxgs9qk';
