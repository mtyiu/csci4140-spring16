module.exports = process.env.MONGOLAB_URI || 'mongodb://XXX';
